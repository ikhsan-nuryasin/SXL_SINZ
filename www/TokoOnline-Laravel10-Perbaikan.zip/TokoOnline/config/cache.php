<?php
return ['default'=>env('CACHE_DRIVER','file'),'stores'=>['file'=>['driver'=>'file','path'=>storage_path('framework/cache/data')],'array'=>['driver'=>'array','serialize'=>false]],'prefix'=>'tokoonline_cache'];
